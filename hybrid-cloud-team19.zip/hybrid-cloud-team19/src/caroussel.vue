<template>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
          <div class="carousel-item active">
              <img class="d-block w-100" src="https://wikitravel.org/upload/shared//b/b0/Ghent_banner.jpg" alt="First slide">
          </div>
          <div class="carousel-item">
              <img class="d-block w-100" src="https://drive.google.com/uc?export=view&id=1eV9zk83ADP7cI1EAPHxv6YaFGhRg7P73" alt="Second slide">
          </div>
          <div class="carousel-item">
              <img class="d-block w-100" src="https://wikitravel.org/upload/shared//8/8e/Bruges_Banner.jpg" alt="Third slide">
          </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
      </a>
      <h2>Do more and spend less. You'll wonder how you ever lived without it...</h2>
  </div>
</template>
