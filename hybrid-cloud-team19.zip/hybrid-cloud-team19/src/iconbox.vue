<template>
    <div class="container">
		<div class="row">
			<!-- Boxes de Acoes -->
			<div class="col-xs-12 col-sm-6 col-lg-4">
				<div class="box">							
					<div class="icon">
						<div class="image">
							<i class="fa fa-briefcase fa-lg"></i>
							</div>
						<div class="info">
							<h3 class="title">Over 1000 business already signed for 2022</h3>
						</div>
					</div>
					<div class="space"></div>
				</div> 
			</div>
				
			<div class="col-xs-12 col-sm-6 col-lg-4">
				<div class="box">							
					<div class="icon">
						<div class="image">
							<i class="fa fa-trophy"></i>
							</div>
						<div class="info">
							<h3 class="title">Innovative APP award 2021</h3>
						</div>
					</div>
					<div class="space"></div>
				</div> 
			</div>
				
			<div class="col-xs-12 col-sm-6 col-lg-4">
				<div class="box">							
					<div class="icon">
						<div class="image">
							<i class="fa fa-home"></i>
							</div>
						<div class="info">
							<h3 class="title">Boost local economy</h3>
						</div>
					</div>
					<div class="space"></div>
				</div> 
			</div>		    
			<!-- /Boxes de Acoes -->
	</div>
</div>
</template>